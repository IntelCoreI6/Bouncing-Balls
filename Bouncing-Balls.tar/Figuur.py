class Figuur:
    def __init__(self, cox, coy, kleur):
        self.cox = cox
        self.coy = coy
        self.kleur = kleur

